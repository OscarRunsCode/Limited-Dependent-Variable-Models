% Computer HW 8 
clear
clc
load martins;
% shorten length of pexpchd2;
pexpch2=pexpchd2;
save martins1;
clear;

% Now identify common threshold and transform lwage
load martins1;
nemploy=(employ==0);
nobs=size(employ,1);

% create vector of maximums ;
mins=ones(nobs,1).*max(lwage);
lwage2=lwage.*employ+mins.*nemploy;
% generate lambda;
lambda=min(lwage2)
% create transformed dependent variable as lwage2;
% lwage2 equals lwage minus the minimum of non-zero ;
% values when employ=1 and 0 otherwise;
lwage2=(lwage2-lambda).*employ;
wage2=exp(lwage2);
clear lambda nobs ans;
save martins2;
clear;

%define text strings for tobit models;
data='martins2'; 
dep2='lwage2';
ind='edu     pexp    pexp2   pexpchd pexpch2 '; 
bin='employ';

% Use HL to generate startingvalues;
[s1b,s2b]=tobit_hl(data,dep2,bin,ind);
theta=tobit2a(data,dep2,bin,ind,s2b);
theta(7)=exp(theta(7));
fprintf('Common Threshold Model (based on Transformed lwage)');
[theta, vc,stderr]=tobit3(data,dep2,bin,ind,theta);

%95% Confidence Interval
BCo=theta(2);
BErr=stderr(2);
LBCI=BCo-1.96*BErr;   %Lower CI
HBCI=BCo+1.96*BErr;   %Upper CI
fprintf('\n');
fprintf('\n-----------Part A--------------- \n');
fprintf('---Confidence Interval---\n');
fprintf('(%2.4f,%2.4f)',LBCI, HBCI);

%Part B
fprintf('\n');
fprintf('\n-----------Part B--------------- \n');
fprintf('---Variance-Covariance Matrix---\n');
vc
fprintf('    Alpha      Beta     Delta     Gamma     Theta     Lambda     Sigma \n');


%Part B

% get stats needed for marginal effect
load martins
lwage(lwage==0)=NaN;
M=[child, pexp, edu, lwage];
fprintf('\n---Median Values---');
MED=nanmedian(M)
MWAGE=exp(MED(1,4)); MPEXP=MED(1,2); MCHD=MED(1,1); MEDU=MED(1,3);
fprintf('    child     pexp        edu     lwage\n');

%Variances
fprintf('\n---Variance---');
VB=vc(2,2); VD=vc(3,3); VG=vc(4,4); VT=vc(5,5); VL=vc(6,6); CDG=vc(3,4); CDT=vc(3,5); 
CDL=vc(3,6); CGT=vc(4,5); CGL=vc(4,6); CTL=vc(5,6);

%Could've combined them all into one equation but this is easier to error
%correct
VARR1=(VD+4*VG*MPEXP^2+MCHD^2*VT+4*MPEXP^2*MCHD^2*VL);
VARR2=2*2*MPEXP*CDG+2*MCHD*CDT+2*2*MPEXP*MCHD*CDL;
VARR3=2*2*MPEXP*MCHD*CGT+2*2*MPEXP*2*MPEXP*MCHD*CGL;
VARR4=2*MCHD*2*MPEXP*MCHD*CTL;
VSUM=VARR1+VARR2+VARR3+VARR4
VMARG=MWAGE^2*VSUM
MARGSD=sqrt(VMARG)
