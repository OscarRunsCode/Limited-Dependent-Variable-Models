Listing of ECO5427 Program Files

1.   The file ols.m is an Octave function file for OLS estimation used in Computer Homework 3.

2.   The file probit.m is an Octave function file for estimation of a Probit model used in Computer Homework 3.

3.   The file prob_bhhh.m is an Octave function file for evaluating the gradient of the Probit model. This function is called by probit.m.

4.   The file prob_logl.m is an Octave function file for evaluating the log-likelihood function of the Probit model. This function is called by probit.m.

5.   The file probit_marg.m is an Octave function file that provides estimates of the marginal effects of regressors in a Probit model.

6.   The file select_hl.m is an Octave function file that provides Heckman-Lee estimates of a Selection model.

7.   The file tobit_hl.m is an Octave function file that provides Heckman-Lee estimates of a Tobit model.

